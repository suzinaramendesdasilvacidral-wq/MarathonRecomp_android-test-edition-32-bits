#pragma once

#include <Marathon.inl>
#include <Sonicteam/MyRenderProcess.h>

namespace Sonicteam::RenderAction
{
    class SetFovY : public MyRenderProcess
    {
    public:
        be<uint32_t> m_CameraIndex;
        be<float> m_FovY;
    };

    MARATHON_ASSERT_OFFSETOF(SetFovY, m_CameraIndex, 0x38);
    MARATHON_ASSERT_OFFSETOF(SetFovY, m_FovY, 0x3C);
    MARATHON_ASSERT_SIZEOF(SetFovY, 0x40);
}
